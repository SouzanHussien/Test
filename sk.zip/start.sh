python3 sk.py
